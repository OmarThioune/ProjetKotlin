import java.io.File

// Data class pour le personnage
data class Personnage(val nom: String, val classe: String, val pointsDeVie: Int)

val personnages = mutableListOf<Personnage>()

// Fonction pour importer les personnages depuis un fichier
fun importerPersonnages() {
    try {
        val file = File("src/personnage.txt") // Accède au fichier
        val lignes = file.readLines() // Lis toutes les lignes du fichier

        // Ajouter chaque ligne comme un nouveau personnage à la liste
        lignes.forEach {
            val donnees = it.split(",") // Divise chaque ligne en 3 parties : nom, classe, pointsDeVie
            if (donnees.size == 3) {
                val personnage = Personnage(donnees[0], donnees[1], donnees[2].toInt()) // Crée un objet Personnage
                personnages.add(personnage) // Ajoute le personnage à la liste
            }
        }

        println("Personnages importés avec succès.")
    } catch (e: Exception) {
        println("Erreur lors de l'importation des personnages : ${e.message}")
    }
}

// Fonction pour copier un personnage
fun copierPersonnage() {
    println("Entrez le nom du personnage à copier : ")
    val nomCopie = readLine() ?: ""

    // Recherche du personnage par son nom
    for (personnage in personnages) {
        if (personnage.nom == nomCopie) {
            val copie = personnage.copy(nom = "${personnage.nom} (copié)") // Copie du personnage avec un nom modifié
            personnages.add(copie)
            println("Personnage copié avec succès : $copie")
            return
        }
    }

    println("Aucun personnage trouvé avec ce nom.")
}

// Fonction pour créer un personnage
fun creerPersonnage() {
    println("Entrez le nom du personnage : ")
    val nom = readLine() ?: ""
    println("Entrez la classe du personnage : ")
    val classe = readLine() ?: ""
    println("Entrez les points de vie du personnage : ")
    val pointsDeVie = readLine()?.toIntOrNull() ?: 0

    val nouveauPersonnage = Personnage(nom, classe, pointsDeVie)
    personnages.add(nouveauPersonnage)
    println("Nouveau personnage créé : $nouveauPersonnage")
}

// Fonction pour afficher tous les personnages
fun afficherPersonnages() {
    if (personnages.isEmpty()) {
        println("Aucun personnage disponible.")
    } else {
        println("Liste des personnages :")
        personnages.forEach {
            println("Nom: ${it.nom}, Classe: ${it.classe}, Points de Vie: ${it.pointsDeVie}")
        }
    }
}

// Fonction pour le menu
fun menuDebug() {
    var continuer = true
    while (continuer) {
        println("\nChoisissez une option :")
        println("A: Importer les personnages")
        println("B: Copier un personnage")
        println("C: Créer un personnage")
        println("D: Afficher tous les personnages")
        println("Q: Quitter")
        print("Entrez votre choix : ")

        when (readLine()) {
            "A" -> importerPersonnages()  // Importer les personnages depuis un fichier
            "B" -> copierPersonnage()     // Copier un personnage
            "C" -> creerPersonnage()      // Créer un nouveau personnage
            "D" -> afficherPersonnages()  // Afficher tous les personnages
            "Q" -> continuer = false      // Quitter le programme
            else -> println("Choix invalide.")
        }
    }
}

fun main() {
    menuDebug()
}
